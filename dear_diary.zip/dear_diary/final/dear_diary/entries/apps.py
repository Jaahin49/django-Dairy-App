from django.apps import AppConfig


class EntriesConfig(AppConfig):
    name = 'entries'
